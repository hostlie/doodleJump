Dans le jeu :
- Player (tirs, mirror jump)
- Platformes (normales, cassantes, tombantes, montantes)
- Items (casquettes, fusées, ressorts)
- Monstres
- Score (hauteur)

Répartition du développement du jeu :
- Axel : Platformes, Items
